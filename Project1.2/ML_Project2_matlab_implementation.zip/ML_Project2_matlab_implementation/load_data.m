load('synthetic.mat');
